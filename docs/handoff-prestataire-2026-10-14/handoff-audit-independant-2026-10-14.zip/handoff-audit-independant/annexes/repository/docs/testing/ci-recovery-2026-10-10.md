# Réparation des contrôles CI — 2026-10-10

## Échecs observables avant modification

- L'audit bloque des versions vulnérables effectivement présentes dans le
  lockfile. Mettre à jour les versions corrigées, supprimer la chaîne `braces`
  sans exception d'audit et conserver toutes les règles ESLint Next.
- Le contrôleur de synchronisation compte 1 249 lignes non vides pour un plafond
  de 1 200. Déplacer ses contrats de types dans son module existant, sans modifier
  l'autosave, les verrous, les conflits ou les exports publics.
- Le setup Playwright expire après 90 secondes ; son helper remplit le formulaire
  sans établir l'hydratation et attend trois fois une redirection en masquant les
  erreurs. Le smoke TesterArmy et la connexion ARMY vérifient déjà le toggle du
  mot de passe. La régression doit établir qu'un formulaire rendu avant ses
  handlers ne reçoit aucun secret, que la connexion réussie est conservée et
  qu'une erreur de credentials est remontée sans répétition inutile.

## Scénarios et exceptions d'isolation

La connexion réelle et les parcours métier restent validés par leurs runners
existants. Le checkout local n'a pas de mot de passe E2E : aucun accès ou compte
ne sera changé pour contourner ce manque. La CI conserve son compte et son
environnement autorisés. Le navigateur anonyme observe le formulaire réel et
les réponses publiques du service.

Une fixture navigateur ciblée du helper de connexion utilise uniquement des
valeurs synthétiques, des handlers volontairement tardifs et une API locale.
Elle couvre une course que la CI et l'E2E normale ne peuvent imposer de manière
reproductible. Elle ne prétend pas établir une authentification Supabase réelle.
Elle est écrite et exécutée avant de modifier le helper.

Les patterns de répertoires ESLint constituent une autre exception d'isolation :
ils sont évalués pendant le lint, sans parcours UI. Les régressions appellent
le véritable `getRootDirs` du plugin Next sur des répertoires jetables : un
répertoire littéral ne doit pas inclure ses descendants, les braces et tableaux
gardent leur sélection, et un pattern fortement imbriqué ne doit pas épuiser la
pile. `tinyglobby` seul n'est pas équivalent : son expansion de répertoire par
défaut, ses séparateurs finaux, plages de braces, parenthèses littérales et
globstars initiaux répétés doivent être adaptés au contrat observé. La revue
indépendante a reproduit ces trois derniers écarts contre Fast-glob 3.3.1 ;
les régressions ont échoué avant leur correction. Le paquet local conserve
les sélections ordinaires et refuse explicitement les motifs excessifs
(4 096 caractères, 64 niveaux imbriqués, 1 000 expansions).

Le contrôle d'architecture existant et les régressions du hook couvrent le
déplacement des types. Aucun test de getter ou de texte source n'est ajouté.

## Résultats

- Base : `8b07ea0c2a453b5cca42f6893c4453b5a663b83d`, Node 24.21.0,
  macOS arm64. Le checkout conserve le WIP utilisateur antérieur ; le commit
  exclut ce WIP, notamment le script d'association article dans `package.json`.
- `npm ci` dans un répertoire temporaire neuf : 819 paquets installés,
  0 vulnérabilité. `.npmrc` impose l'empaquetage des dépendances locales pour
  rendre leur résolution reproductible. Le code empaqueté a le même SHA-256
  que la source ; le vrai plugin Next retrouve les racines numériques/littérales.
- `npm run audit:dependencies` : 0 advisory bloquant, 0 exception active.
  `npm run audit:signatures` : 816 signatures et 220 attestations vérifiées.
  Les versions de Vitest/coverage sont alignées sur 4.1.11 ; le SDK MCP transitif
  de `e2e` est corrigé sans changer les versions des runners E2E.
- `npm run check:architecture` : vert, 1 015 modules, aucun cycle autorisé.
  Le contrôleur passe de 1 249 à 1 154 lignes non vides pour un plafond de
  1 200. Son JavaScript transpilé est identique ; les 36 régressions du hook
  passent et figurent dans la suite globale.
- `npm test` : 432 fichiers verts, 2 703 assertions actives vertes,
  1 fichier / 2 assertions ignorés. Les 9 régressions du glob et 8 gardes
  d'audit passent aussi en exécution ciblée. Couverture critique : 12/12,
  exécutée pendant ce lot avec les mêmes versions Vitest/coverage.
- `npx playwright test --config e2e/auth/playwright.config.ts` : 2/2 verts,
  Chromium headless, valeurs synthétiques seulement. Ce contrôle est ajouté
  au workflow critique avant l'étape recevant ses secrets.
- `npm run e2e:army` : 2/2 smokes anonymes verts, hydratation réelle,
  `e2e` 0.15.2, `@e2e-dev/web` 0.11.1, Playwright 1.63.0 ; manifest et
  rapport sous `.e2e/army/`. Ces smokes ne prouvent pas une connexion Supabase.
- Lint global, typecheck, OpenAPI, `git diff --check` et
  `npm run verify:production` verts. Ce dernier construit avec Webpack,
  démarre un serveur local, vérifie pages/redirect/assets et arrête ses processus.
- La CI publiée et la connexion réelle sont à vérifier après le push sur
  le SHA du commit. Aucune migration Supabase n'est modifiée par ce lot ;
  les preuves pgTAP/RLS du précédent SHA ne sont pas une nouvelle exécution.

L'hydratation est établie par le toggle non secret avant de remplir le
formulaire. Le helper masque à nouveau le mot de passe, attend la redirection
ou l'erreur affichée et remonte un rejet sans le répéter. Les identifiants
sont retirés des messages d'erreur. L'authentification et la persistance métier
restent qualifiées par la suite critique existante sur le SHA poussé.

La suppression de `braces` vise une dépendance de lint, dont le consommateur
direct est le `getRootDirs` du plugin Next ; elle ne requalifie pas un chemin
d'attaque HTTP. Références amont :
[avis braces](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm),
[contrat Fast-glob](https://github.com/mrmlnc/fast-glob/blob/3.3.1/src/utils/pattern.ts),
[expansion bornée](https://github.com/juliangruber/brace-expansion/blob/v5.0.12/src/index.ts),
[correctif Vitest](https://github.com/vitest-dev/vitest/security/advisories/GHSA-82fw-gwwq-j7x9).

## Complément après la première CI publiée

Sur `c74696f4`, installation, audit, signatures, architecture, lint, typecheck,
OpenAPI, tests Node, couverture critique, build/smoke HTTP et TesterArmy sont
verts dans GitHub Actions. Deux limites ont été établies par cette exécution :

- Supabase Auth renvoie réellement `invalid_credentials` à la connexion CI.
  Les régressions synthétiques du helper passent 2/2 ; les 36 parcours métier
  restent non exécutés. Corriger le compte/secret nécessite une décision
  distincte de la correction du code ; aucun accès n'a été changé à ce stade.
- La suite jsdom expose une course de sa fixture `GeneratedOuvrageDialog` :
  attendre le début de l'API de validation ne garantit pas l'état visible
  « Revu ». Le clic sur le bouton encore désactivé ne déclenche donc pas la
  barrière de mutation. Une réponse volontairement retardée reproduit le même
  échec localement avant correction. Le helper attend désormais le badge
  « Revu » ; le test vérifie le bouton activé avant de cliquer et conserve
  le refus de la barrière et l'absence d'appel à l'API d'insertion.

Ce complément corrige la synchronisation de la fixture, sans changer le
comportement applicatif, désactiver une assertion ou augmenter les retries.
Validation : 8/8 tests ciblés, puis la suite jsdom entière sous les variables
factices de la CI (162 fichiers, 823 tests), lint ciblé et typecheck verts.

## Connexion réelle rétablie et parcours métier révélés

Sur `61e63d4a`, le Quality Gate et le smoke TesterArmy sont verts. Après
l'autorisation explicite de réinitialiser le seul compte ARMY, sa connexion
Supabase est vérifiée et ses identifiants sont synchronisés localement et dans
l'environnement GitHub `e2e-staging`. Le rôle admin et l'unique appartenance au
tenant ARMY restent identiques. Les secrets restent hors Git ; le contrôle des
rapports a ensuite révélé la fuite décrite ci-dessous.

La seconde tentative du workflow critique `38042306101` établit la connexion
et passe 35 tests. Elle révèle deux échecs auparavant masqués par le setup :

- Le scénario métré attend la carte d'un hub opérationnel sur une affaire sans
  lignes ni pièces. Il crée un jeu de plans vide et ne téléverse aucun fichier,
  malgré son titre mentionnant un CSV. Le contrat actuel lance les jeux de plans
  PDF en Standard/Détaillé et expose le centre d'activité par un lien.
  La fixture doit créer une ligne enregistrée et téléverser le PDF existant,
  vérifier le jeu retenu et la version cible, puis établir la demande persistée
  et la navigation depuis l'action du menu « Plus ». Seule cette demande de test
  est annulée si encore active ;
  ce contrôle ne qualifie pas l'extraction par le worker.
- La simulation DPGF atteint bien import et mapping, puis l'API catalogue échoue
  avec `42703`: `products.reference_normalized` n'existe pas en production.
  Les deux colonnes générées et la migration `20260819205115` sont absentes.
  Le pré-vol lit 1 286 produits, aucune collision de références normalisées et
  une table de 10 895 360 octets. La correction prévue est la migration existante,
  avec ses garde-fous transactionnels, sans supprimer l'assertion de simulation
  ni introduire un fallback qui abandonnerait l'unicité insensible à la casse.
  Son application distante demande une autorisation distincte du reset ARMY.

Avant application, vérifier en PostgreSQL isolé la conservation des valeurs,
les formes générées, le refus des doublons dans un tenant, leur acceptation
entre tenants, les références vides, les index, l'idempotence et le rollback
intégral en présence d'une collision. Puis rejouer l'E2E réelle sur le SHA poussé.

Après autorisation explicite, la migration exacte est appliquée le 2026-10-10.
Les 1 286 produits et l'empreinte de toutes leurs valeurs antérieures sont
identiques avant/après ; les deux colonnes sont générées, aucun rapprochement
normalisé ne diffère de `trim + lower`, et les deux nouveaux index sont valides.
L'historique de cette seule application est aligné sur la version du dépôt
`20260819205115` (le connecteur avait généré `20261010104912`). Les constats
des conseillers sécurité sont identiques avant/après, hors heure d'observation.

La migration passe 12 vérifications en PostgreSQL isolé, dont l'échec avant
correction (`42703`), le rollback sur collision et une seconde application
idempotente. Ce contrôle ciblé ne constitue pas un nouveau replay pgTAP/RLS.

Deux probes locaux passent avec Supabase réel et des traces authentifiées
désactivées :

- Métré : un replay ciblé sur le brouillon et le jeu créés par cette invocation
  CI, avec la ligne et le PDF déjà vérifiés. Le job est nouvellement créé,
  vérifié par l'API et annulé ; le lien ouvre le centre d'activité. L'absence
  locale de clé service-role empêche de qualifier le dispatch worker ou la
  création canonique du brouillon dans cette probe. Le replay CI garde une
  affaire entièrement neuve et sa configuration serveur existante.
- DPGF : nouvel import préfixé `ARMY`, mapping enregistré et simulation catalogue
  réelle. L'API renvoie 200, deux lignes analysées, aucune création de produit
  et une répartition liée/non liée exhaustive. Les identités des fixtures sont
  jointes aux rapports Playwright. Le contrôle ultérieur de leur ZIP a révélé
  les identifiants dans les titres SDK de connexion, corrigés ci-dessous.

Lint ciblé, typecheck et contrôle du diff passent. Le replay complet des contrôles
obligatoires reste à vérifier sur le prochain SHA poussé.

## Protection des rapports de connexion

La lecture du ZIP embarqué des rapports HTML locaux révèle les valeurs réelles
du compte dans les titres SDK de `locator.fill()`, malgré les traces désactivées.
L'artefact GitHub `11667038644` de la tentative 2 de `38042306101` est supprimé
après confirmation de cette fuite. Le replay critique `38046578101` sur
`60e2acda` est arrêté avant publication : sa liste d'artefacts est vide.
Les copies locales et les preuves persistantes concernées sont expurgées.

Avant correction du helper, un reporter de la fixture navigateur existante
détecte les credentials synthétiques dans les vrais titres et erreurs des steps
Playwright. Les deux assertions métier passent avant correction, mais le reporter
force correctement un code de sortie 1. Après correction, les deux régressions
passent, reporter compris, sous Node 24.21.0. Les valeurs sont renseignées par
le setter natif du champ et ses événements `input`/`change`, avec un step SDK
générique qui n'incorpore pas son argument. Les deux helpers authentifiés utilisent
ce chemin et les traces restent désactivées, localement aussi.

Le filtre d'upload examine les fichiers de résultat et le ZIP réellement embarqué
dans le HTML. Les credentials absents, un ZIP illisible et les secrets présents
font échouer le contrôle ; l'upload critique et nightly exige sa réussite.
Ses fixtures CLI contiennent de vrais ZIP compressés et des valeurs synthétiques.
Elles sont écrites avant le filtre : l'absence d'implémentation fait échouer la
fixture positive. Un nom HTML en majuscules reproduit aussi un contournement avant
correction. Les six contrôles passent sous Node 24.21.0. `fflate` 0.8.3, déjà présent
transitivement, devient une dépendance de développement directe du filtre.

Une nouvelle probe locale conserve la connexion Supabase réelle, l'import DPGF,
son mapping et la simulation catalogue : 1/1 passe, avec un rapport HTML complet
sans identifiants vérifié par ce filtre. Une première probe utilise Node 26.10.0 ;
elle est ensuite rejouée sous Node 24.21.0 avec le dernier mot de passe ARMY,
avec le même résultat et un nouveau rapport complet contrôlé.

Le Quality Gate de `60e2acda` révèle une assertion de texte obsolète : elle impose
encore le nom d'une condition d'indisponibilité de l'ancien scénario métré.
Cette assertion est retirée : le parcours réel exige désormais le PDF et le job
persisté, et échoue si l'étape requise est indisponible. Les garde-fous de CI,
de secrets, de sélection des parcours et de refus des retries instables restent
actifs ; leur suite ciblée passe 6/6. Le contrôle de traces attend désormais
leur désactivation pour tous les replays authentifiés.

Une dernière rotation du seul compte ARMY est appliquée après la sortie d'outil
du formulaire GitHub. La connexion réelle réussit, un mot de passe incorrect est
refusé, les sessions de ce seul compte sont révoquées et la configuration locale
est synchronisée. L'enregistrement dans GitHub nécessite encore la confirmation
d'accès demandée dans le Chrome personnel. Le replay complet du prochain SHA
reste à vérifier après cette synchronisation.

## Diagnostics API et dernière tentative critique

Après confirmation d'accès dans Chrome personnel, le secret ARMY est enregistré
dans GitHub le 2026-10-10 à 14:37 UTC. La tentative 2 de `38048922470`, sur
`dd4cb991`, passe les 37 tests critiques, sans assertion instable. Le filtre de
confidentialité bloque néanmoins le rapport ; aucun artefact n'est publié.

La réponse d'acquisition du verrou contient l'adresse professionnelle de son
propriétaire. Les messages personnalisés `expect(status, body)` deviennent des
titres SDK même quand l'assertion réussit. Une fixture API locale reproduit ce
cas dans le vrai reporter avant correction : création, duplication et verrou
réussissent, mais les métadonnées exposent l'identité synthétique. Deux autres
contre-exemples échouent : refus de verrou et duplication sans identifiant
révèlent également les credentials dans leurs diagnostics.

Cette isolation couvre la sérialisation du reporter, que les 37 assertions
métier réussies ne détectent pas. La correction doit retirer les credentials
bruts, échappés JSON et encodés URI des seuls diagnostics, conserver le corps
original pour son parsing, et laisser échouer les statuts/payloads invalides.
Le filtre d'upload conserve ses contrôles et la suite critique complète doit
être rejouée sur le nouveau SHA.

Après correction, les cinq fixtures navigateur passent, reporter compris, sous
Node 24.21.0. Les six contrôles du filtre, le lint ciblé, le typecheck et le diff
passent aussi. Le code métier et les assertions de statut/identifiant restent
identiques ; seules les chaînes destinées aux diagnostics sont expurgées.
