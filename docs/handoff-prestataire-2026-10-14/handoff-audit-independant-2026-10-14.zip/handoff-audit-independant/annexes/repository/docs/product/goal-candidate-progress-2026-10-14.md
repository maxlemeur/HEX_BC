# Suivi du goal candidat — 14 octobre 2026

Le goal candidat est créé et actif dans le chat `01a139e8-b8d5-73d3-b169-ff17c0c77776`, avec l'outil `create_goal`, sans budget de tokens. Son résultat est [l'application complète qualifiée localement et le dossier de recette](goal-chiffrage-candidate-2026-10-14.md). L'ancienne vision reste conservée ; elle n'est pas déclarée atteinte. Le parent organise séparément la pause de son ancien goal.

| Ordre | Lot à fermer | État de cette continuation |
| --- | --- | --- |
| 1 | Calcul et saisie fiables, remise exacte et compatibilité | En cours : contrats et nouveaux précode avant produit ; défaut 1,01 € → 2,00 € conservé |
| 2 | Dossier, CCTP A/B, import canonique, sources et corrections | À qualifier sur la pile actuelle ; résultats antérieurs datés |
| 3 | Prestations, bibliothèque et prix fournisseurs | À qualifier dans le parcours complet ; expiration six mois et exclusion zéro conservées |
| 4 | Offre commerciale, validations, exports et portail | Preuves d'émission antérieures datées ; reprise après montant exact |
| 5 | Préparation et suivi chantier | Parcours complet à qualifier, sans engagement externe automatique |
| 6 | Retour d'expérience validé humainement | Apprentissage et effets sur bibliothèque/prix à qualifier |
| 7 | Livraison, droits, reprise, sauvegarde et dossier de recette | Contrôle final à réaliser ; aucun verdict complet depuis une recette filtrée |

Trois dossiers de sortie sont prévus, sans prétendre qu'ils existent déjà : cas CVC/plomberie courant, grande DPGF de 2 004 lignes et révision A/B avec variantes. Leurs identités, données générées, valeurs, sources et résultats seront fixés avant exécution.

La tranche de réglages atomiques et sa rétro du parent sont closes : [qualification](../testing/estimate-settings-atomic-2026-10-14.md) et [rétro](retrospective-settings-chiffrage-2026-10-14.md). Elles ne qualifient pas toute l'application. Cette continuation ne recommence pas ces travaux.

Lecture locale santé/identité : API45585/Auth200 et PostgreSQL33485/sysid7695571534776503175/version170011, RPC settings présente, colonne de montant fixe encore absente. Reçu `.e2e/offer-emission/euro-root-contract-20261014-01/native-health-01.json`. Aucun changement produit, migration ou réparation dans cette nouvelle tranche à ce checkpoint. Le détail avant code est dans `euro-root-contract-20261014-01/contract.md`.

Précode exécuté : EU01 constate 1,01 € devenu 2,00 € sur 1 004 lignes ; EU02 constate l'absence de l'intention fixe en stockage ; EUHIST constate qu'une modification de marge altère le pourcentage historique (3,80 € HT contre 3,60 € attendus). Les assertions publiques de sceaux et de gouvernance ont également reproduit les champs ignorés et les seuils arrondis.

Le contrôle SQL `euro-sql-precode-20261014-01/baseline-shaped-01/receipt.json` est terminal, avec conservation du catalogue, des droits, des multisets de 155 tables et des sources. Il a exercé 47 préparations valides sur 49 ; les deux appels métier de modèles échouent par récursion RLS (`42P17`), actuellement classés comme setup manquant. Cela ne qualifie aucune nouvelle fonctionnalité. Les erreurs et assertions sont conservées avant correction. Le gel V2 nécessite aussi l'adaptation de son contexte canonique : son vrai corps installé a été lu sans mutation. Ces deux frontières sont ajoutées à la correction, sans élargissement des droits.
