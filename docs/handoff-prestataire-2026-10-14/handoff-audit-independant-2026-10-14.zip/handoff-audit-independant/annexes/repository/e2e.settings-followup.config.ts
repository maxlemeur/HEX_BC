// Local followup recipe; no external delivery.
export { default } from "./.e2e/offer-emission/settings-followup-army-20261014-01/config-v2";
