import { z } from "zod";

import {
  readActiveTenantMembership,
  readAuthenticatedUser,
} from "@/lib/auth/tenant-context";
import { badRequest, ok, toErrorResponse, unauthorized } from "@/lib/estimates/errors";
import {
  listFeatureFlagsForTenant,
  normalizeFeatureFlagKey,
  toggleFeatureFlagForTenant,
} from "@/lib/feature-flags";

const tenantQuerySchema = z.object({
  tenant_id: z.string().uuid("tenant_id invalide.").optional(),
  include_inactive: z.boolean().optional(),
});

const patchFeatureFlagSchema = z.object({
  tenant_id: z.string().uuid("tenant_id invalide.").optional(),
  flag_key: z.string().trim().min(1, "flag_key invalide.").max(64, "flag_key invalide."),
  enabled: z.boolean(),
  value: z.union([z.string(), z.null()]).optional(),
});

async function parseJsonBody(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch {
    throw badRequest("Payload JSON invalide.");
  }
}

async function getActorContext() {
  const { supabase, user, error } = await readAuthenticatedUser();

  if (error || !user) {
    throw unauthorized();
  }

  const { membership, error: membershipError } =
    await readActiveTenantMembership(supabase, user.id);

  if (membershipError) {
    throw badRequest("Impossible de charger le tenant courant.");
  }

  const defaultTenantId = membership?.tenant_id ?? null;

  if (!defaultTenantId) {
    throw unauthorized();
  }

  return {
    supabase,
    userId: user.id,
    defaultTenantId,
  };
}

function parseBooleanQueryParam(value: string | null) {
  if (!value) return undefined;

  const normalized = value.trim().toLowerCase();
  if (normalized === "1" || normalized === "true") return true;
  if (normalized === "0" || normalized === "false") return false;

  throw badRequest("include_inactive invalide.");
}

function parseFeatureFlagQuery(request: Request) {
  const searchParams = new URL(request.url).searchParams;
  const parsed = tenantQuerySchema.safeParse({
    tenant_id: searchParams.get("tenant_id") ?? undefined,
    include_inactive: parseBooleanQueryParam(searchParams.get("include_inactive")),
  });

  if (!parsed.success) {
    throw badRequest("tenant_id invalide.");
  }

  return parsed.data;
}

export async function GET(request: Request) {
  try {
    const query = parseFeatureFlagQuery(request);
    const { supabase, userId, defaultTenantId } = await getActorContext();
    const tenantId = query.tenant_id ?? defaultTenantId;
    const flags = await listFeatureFlagsForTenant({
      tenantId,
      userId,
      includeInactive: query.include_inactive === true,
      supabase,
    });

    return ok({
      tenant_id: tenantId,
      flags,
    });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const payload = patchFeatureFlagSchema.parse(await parseJsonBody(request));
    const { supabase, userId, defaultTenantId } = await getActorContext();
    const tenantId = payload.tenant_id ?? defaultTenantId;
    const flag = await toggleFeatureFlagForTenant({
      tenantId,
      userId,
      key: normalizeFeatureFlagKey(payload.flag_key),
      enabled: payload.enabled,
      ...("value" in payload ? { value: payload.value ?? null } : {}),
      supabase,
    });

    return ok({
      tenant_id: tenantId,
      flag,
    });
  } catch (error) {
    return toErrorResponse(error);
  }
}
