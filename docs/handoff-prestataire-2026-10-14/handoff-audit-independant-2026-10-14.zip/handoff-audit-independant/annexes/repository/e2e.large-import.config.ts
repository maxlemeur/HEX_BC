// Stage10 ignored precode is frozen; this root entry keeps SDK projectRoot at the repository.
export { default } from "./.e2e/offer-emission/large-import-army-stage-20261014-11/config-v2";
