// Local owner/print recipe: ordinary UI, owned production build, no external delivery.
export { default } from "./.e2e/offer-emission/owner-print-army-20261014-01/config-v2";
