import { readFile } from "node:fs/promises";
import path from "node:path";

import { expect, test } from "@playwright/test";

import { ensureMapping } from "./helpers";

test.describe("EST-262 - import DPGF", () => {
  test("Scenario 5: importer un DPGF et verifier le mapping", async ({ page }, testInfo) => {
    const fixturePath = path.join(process.cwd(), "e2e/fixtures/dpgf-minimal.csv");
    const fixtureName = `ARMY-DPGF-${Date.now()}.csv`;

    await page.goto("/dashboard/imports");
    await expect(page.getByRole("heading", { name: /Import DPGF/i })).toBeVisible();

    await page.setInputFiles("#import-file-input", {
      name: fixtureName,
      mimeType: "text/csv",
      buffer: await readFile(fixturePath),
    });

    await page
      .getByRole("button", { name: /^(Importer|Lancer l['’]import)$/i })
      .first()
      .click();

    const mapLink = page.getByRole("link", { name: /Mapper les colonnes/i });
    await expect(mapLink).toBeVisible({ timeout: 60_000 });
    const mapHref = await mapLink.getAttribute("href");
    expect(mapHref).not.toBeNull();

    const mapUrl = new URL(mapHref ?? "", "http://localhost");
    const importId = mapUrl.searchParams.get("import_id");
    expect(importId).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
    );
    await testInfo.attach("dpgf-fixture", {
      body: JSON.stringify({ importId, fixtureName }),
      contentType: "application/json",
    });

    await mapLink.click();

    await expect(page).toHaveURL(/\/dashboard\/mappings\?import_id=/i);
    await expect(page.getByRole("heading", { name: /Mapping DPGF/i })).toBeVisible();

    await ensureMapping(page, "hex_code", "hex_code");
    await ensureMapping(page, "designation", "designation");
    await ensureMapping(page, "unit_price_ht", "unit_price_ht");

    await page.getByRole("button", { name: /Enregistrer le mapping/i }).click();

    const mappingSavedBanner = page.getByText(/Mapping enregistr[ée] avec succ[eè]s/i);
    const mappingMemoryErrorBanner = page.getByText(
      /Impossible de mettre a jour la memoire de mapping/i
    );

    const saveOutcome = await Promise.race([
      mappingSavedBanner.waitFor({ state: "visible", timeout: 60_000 }).then(() => "saved"),
      mappingMemoryErrorBanner
        .waitFor({ state: "visible", timeout: 60_000 })
        .then(() => "saved-with-memory-error"),
    ]).catch(() => "unknown");

    if (saveOutcome === "unknown") {
      throw new Error(
        "Le mapping n'a pas pu etre confirme: aucun message de succes detecte apres l'enregistrement."
      );
    }

    if (saveOutcome === "saved") {
      await page.getByRole("link", { name: /Lier au catalogue/i }).click();
    } else {
      await page.goto(`/dashboard/catalogue?import_id=${importId}`);
    }

    await expect(page).toHaveURL(/\/dashboard\/catalogue\?import_id=/i);
    await page.getByRole("tab", { name: /Liaison lignes import[ée]es/i }).click();

    await expect(page.locator("#catalogue-link-import-id")).toHaveValue(importId ?? "");

    const simulationCheckbox = page.getByLabel(/Simulation/i);
    if (!(await simulationCheckbox.isChecked())) {
      await simulationCheckbox.check();
    }

    const [linkResponse] = await Promise.all([
      page.waitForResponse((response) =>
        new URL(response.url()).pathname === "/api/catalogue"
        && response.request().method() === "POST",
      ),
      page.getByRole("button", { name: /Lancer la liaison/i }).click(),
    ]);
    expect(linkResponse.status(), "The catalogue simulation must succeed").toBe(200);
    const summary = (await linkResponse.json()).data;
    expect(summary).toMatchObject({
      import_id: importId,
      dry_run: true,
      scanned_rows: 2,
      created_catalogue_count: 0,
    });
    expect(summary.linked_count + summary.unmatched_count).toBe(2);

    await expect(
      page.getByText(/Simulation termin[ée]e|Liaison termin[ée]e/i)
    ).toBeVisible({ timeout: 60_000 });
  });
});
