// Local fixed discount recipe: ordinary UI, owned production build, no external delivery.
export { default } from "./.e2e/offer-emission/euro-army-precode-20261014-01/config-v2";
