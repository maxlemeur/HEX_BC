# Remise fixe : contrat effectif avant produit

Goal actif de ce chat : 01a139e8-b8d5-73d3-b169-ff17c0c77776. Même checkout main/ce5874f54f8202297b74e4ed238e5c48e49d2f1b ; aucun changement produit de ce lot pour l'instant. La tranche réglages/rétro précédente est close et ne doit pas être rejouée.

Référence prospective : ../settings-euro-design-20261014-01/contract.md, SHA a323af8a6106334a6c9ab70a8109ab13f3f035ef71cb188c1d4dc2eed341ae58. Trois précode indépendants : euro-army-precode-20261014-01, euro-sql-precode-20261014-01, euro-seal-governance-precode-20261014-01.

## Invariants à qualifier

- `discount_amount_cents` nullable sur versions et modèles : NULL ou propriété historique absente conserve le contrat pourcentage/cascade ; non NULL est l'intention fixe, y compris zéro explicite. Aucun backfill convertissant les pourcentages.
- Le montant demandé demeure 101 même lorsque l'assiette devient 50. Le calcul applique min(demandé, assiette), puis retrouve 101 quand l'assiette remonte. L'UI expose l'intention dans la saisie et le calcul appliqué dans les totaux.
- Une saisie explicite Remise bascule en fixe ; titre, marge, quantité ou TVA seuls ne le font pas. Conserver le BP historique et les paliers cascade. Le premier palier simple demeure une compatibilité de document/parser ; les CHECKs versions/templates validés interdisent cette forme en stockage actuel (comptage live0/0). Ne pas élargir ces CHECKs pour créer une nouvelle configuration illégale. Le coefficient reste indépendant.
- Pour le fixe, simple et steps vides. Contradiction effective, montant négatif/fractionnaire/hors limite, contexte/acteur/bail/CAS invalides : rejet avant mutation ou rollback total.
- Chaque recalcul, copie, nouvelle version, modèle, application métré et export conserve le montant exact. V1 garde les lignes brutes ; V2 garde ses lignes nettes et allocations. Ne pas déduire une seconde remise d'un snapshot net.
- Le seuil max_discount reçoit une preuve canonique exacte de l'assiette et de l'appliqué, sans BP arrondi autoritaire. L'assiette indisponible ne vaut pas remise zéro/ready. Les seuils décimaux historiques restent admis ; direction utilise 800 BP, non 1000.
- Modifier 101 vers 102 invalide décisions et snapshot même si les BP équivalents sont identiques. Les sceaux historiques NULL/absents restent byte-identiques ; le montant non NULL participe au payload calcul v4 puis à l'enveloppe v5 existante.
- Les wrappers de duplication produit restent en place. Étendre le vrai corps interne, la copie de modèle et le créateur canonique ; ne pas réactiver les créateurs legacy révoqués.

Le seam exact de gouvernance est en cours d'audit précode : signal conditionnel dans une capture fraîche ou calcul canonique authentifié, avec identité de contenu. Ne pas multiplier les colonnes dérivées ni reconstruire l'assiette depuis les lignes nettes.

## RED exécutés avant produit

- EU01, build sIZ7nOQ8chXqN9XTjCCTz, run `2026-10-14T10-40-35-798Z-40e3f983-025c-468b-8021-0fbab9adcd32` : sauvegarde réelle1004lignes, un PATCH200, montant1,01 devient2,00. Pied constaté `[1995250,399090,2394340,0]` contre `[1995349,399090,2394439,0]` ; login passe, métier échoue, sources stables.
- EU02, run `2026-10-14T10-44-05-208Z-4e049b89-11fa-4e5a-9b6d-5f13d20b9ef5` : premier montant101 sur assiette200 calcule les bons montants mais le stockage explicite est absent. La séquence de plafonnement/remontée n'a pas encore été atteinte : preuve manquante, pas qualification de ces étapes.
- EUHIST, run `2026-10-14T10-46-08-087Z-16b135e5-7237-418a-bf2a-d293835a35eb` : marge changée sans ressaisir la remise historique ; pied `[380,76,456,0]` au lieu de `[360,72,432,0]`. Étapes ultérieures encore non exécutées. La préparation simple+paliers sera désormais une assertion de rejet sur contrat de stockage existant, avant code.
- Spécialiste seal :146assertions,140PASS/6RED de montant ignoré ; calculs historiques48/48PASS. Réel evaluateRules avec provider minimal :26cas,6PASS/20RED (seuils exacts et captures absentes/périmées/contradictoires). Cette isolation ne qualifie pas l'origine authentique des captures, les ACL ou la direction UI.

Toutes les fenêtres UI ci-dessus sont terminales. Les fixtures et anciennes pins/assertions restent conservées. Les corrections de précode de fraîcheur et de stockage simple/paliers sont effectuées avant toute implémentation produit. La lecture live de cette dernière contrainte est `../euro-sql-precode-20261014-01/read-firststep-01.json`, SHA0999a745009d0fcff5a77b12df97d3b4a6a36b365690183d3ff4da65c1b00568.

## Autorité et exécution

Les prochaines migrations locales nécessaires préparées/revues/testées sont autorisées sur API45585/DB33485. Lecture santé/identité du 14 octobre : native-health-01.json, SHA50d532d4571d297cb4cd2e00ff1ffc71dc268dc203dcee439b103d86154d9c55, PostgreSQL sysid7695571534776503175/version170011, lecture readonly, Auth200, settingsRPC installée et nouvelle colonne absente. Aucune réparation ou mutation effectuée. Le premier accès WSL sandbox a été refusé ; le même lecteur hors sandbox a passé.

Écrire et figer les nouvelles assertions avant produit. Exécuter les nouveaux RED UI et spécialistes, sans montant préinséré ni modification d'autorisation, puis commencer une implémentation cohérente. SQL rollback/concurrence est une exception justifiée pour l'annulation tardive et les accès hors UI ; les vecteurs de sceaux préservent précisément des formats historiques que quelques recettes PDF ne couvrent pas. Aucun nouveau test unitaire de forwarding/getter après code.

Fenêtres SQL/UI sérialisées par root ; sources figées pendant recettes. Toute panne conserve son reçu et requiert une nouvelle autorisation avant réparation. Aucune publication, mutation distante, reset/stop ou modification des identités/roles. Les anciennes preuves restent datées.
