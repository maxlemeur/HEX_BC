import { createHash } from "node:crypto";
import { mkdir,readFile,readdir,writeFile } from "node:fs/promises";
import path from "node:path";
import { expect } from "e2e";
import type { Browser } from "@e2e-dev/web";
import { apiRequest,createEstimateViaWizard,ownEstimate,readEstimate,type ArmyEstimate,type ArmyVersion,type ArmyItem } from "../../../e2e/army/critical/fixtures";
import { offerTest,recordOfferEvidence } from "./offer-import-fixtures";
import { importGuard } from "./import-guard";


let readSequence=0;
type ObservedEnvelope={ok:boolean;data:{version:ArmyVersion;items:ArmyItem[]};error?:{code?:string}};
async function readEstimateObserved(browser:Browser,versionId:string,witness:(label:string,observed:Record<string,unknown>)=>Promise<unknown>):Promise<ArmyEstimate>{
  const startedAt=new Date().toISOString();
  const response=await apiRequest<ObservedEnvelope>(browser,"GET",`/api/estimates/${versionId}`);
  const version=response.body?.data?.version;
  const projection=version?Object.fromEntries(["id","tenant_id","project_id","status","updated_at","content_revision","approval_evaluated_at"].filter(key=>Object.hasOwn(version,key)).map(key=>[key,version[key]])):null;
  await witness(`owner-get-http-${String(++readSequence).padStart(4,"0")}`,{startedAt,finishedAt:new Date().toISOString(),status:response.status,ok:response.body?.ok===true,errorCode:typeof response.body?.error?.code==="string"?response.body.error.code:null,version:projection,singleOriginalRequest:true,retried:false});
  expect(response.status).toBe(200);
  expect(response.body.ok).toBe(true);
  const {version:loaded,items}=response.body.data;
  return{project:loaded.estimate_projects,version:loaded,items};
}

const approvalProjectionKeys=new Set(["approval_status","approval_summary","approval_evaluated_at"]);
function withoutApprovalProjection(estimate:ArmyEstimate):ArmyEstimate{
  const version={...estimate.version};
  for(const key of approvalProjectionKeys)delete version[key];
  return{...estimate,version};
}

type Line={rowIndex:number;reference:string;marker:string;title:string;quantityText:string;quantity:number;unit:string;unitPriceCents:number;saleHtCents:number;taxCents:number;totalTtcCents:number;position:number};
type Oracle={caseCode:string;filename:string;sha256:string;lineCount:number;expectedItemCount:number;expectedTotals:{totalHtCents:number;taxCents:number;payableTtcCents:number};settings:Record<string,unknown>;lines:Line[]};
type ImportRecord={id:string;project_id:string;filename:string;row_count:number;source_format:string;status:string};
const directory=path.resolve(".e2e/offer-emission/euro-army-precode-20261014-01");
const digest=(bytes:string|Buffer)=>createHash("sha256").update(bytes).digest("hex");
const UUID=/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i;
const fields=["hex_code","designation","quantity","unit","unit_price_ht","total_ht"];
const mapping=Object.fromEntries(fields.map(key=>[key,key]));
const money=(n:number)=>`${Math.floor(n/100)},${String(n%100).padStart(2,"0")}`;
const totals=(v:Record<string,unknown>)=>[v.total_ht_cents,v.total_tax_cents,v.total_ttc_cents];
const packet=JSON.parse(await readFile(path.join(directory,"dossier-oracle.json"),"utf8"))as{fixtures:Oracle[]};

type FinancialLine={rowIndex:number;quantity:number;quantityText:string;netHtCents:number;taxCents:number;ttcCents:number;snapshotPuHtCents:number};
type FinancialStage={label:string;action:"settings"|"quantity"|"api-prepare"|"api-refuse";quantityText:string;requestedDiscountCents:number|null;appliedDiscountCents:number;saleSubtotalCents:number;globalCoefficient:number;margin:number;totals:number[];lines:FinancialLine[];fillMargin?:number;fillDiscountCents?:number;fillTitle?:boolean;discountMode?:"simple"|"cascade";discountBp?:number;discountSteps?:number[];preparationPatch?:Record<string,string|number|null|number[]>;expectedHttpStatus?:number;expectedErrorCode?:string};
const financialBytes=await readFile(".e2e/offer-emission/euro-army-precode-20261014-01/financial-oracle.v3.json");
const financialOracleSha256=digest(financialBytes);
if(financialOracleSha256!=="2104e9443027ca55e8f7fb71bca03a9786e5c861778cbbd43f34d7f52618a7a9")throw new Error("Precode independent financial oracle changed.");
const financialPacket=JSON.parse(financialBytes.toString()) as {fixtures:Array<{caseCode:string;lineCount:number;stages:FinancialStage[]}>};
const financialTotals=(v:Record<string,unknown>)=>[v.total_ht_cents,v.total_tax_cents,v.total_ttc_cents,v.rounding_adjustment_cents];

for(const selectedCase of [{code:"EU01",lineCount:1004},{code:"EU02",lineCount:1},{code:"EUHIST",lineCount:1}])offerTest(`${selectedCase.code} exact fixed amount and historical intent survive real UI save and reload`,
  {session:"army",trace:"off",tags:["offer-emission","large-import"],timeout:900000},async ui=>{
  const {lineCount,code}=selectedCase;
  const oracle=packet.fixtures.find(value=>value.caseCode===code)!;
  const finance=financialPacket.fixtures.find(value=>value.caseCode===code)!;
  expect(oracle.expectedItemCount).toBe(lineCount+1);
  const expectedTotals=[oracle.expectedTotals.totalHtCents,oracle.expectedTotals.taxCents,oracle.expectedTotals.payableTtcCents];
  const file=path.join(directory,oracle.filename);expect(digest(await readFile(file))).toBe(oracle.sha256);
  const originalName=`${ui.army.runPrefix}-${code}-ORIGINAL`;
  ui.army.projectName=originalName;
  const guard=await importGuard(ui.browser,new URL(ui.app.baseUrl!).origin,oracle.filename,oracle.lines,ui.army);
  let stage="wizard",projectId:string|null=null,versionId:string|null=null,importId:string|null=null;
  let primaryFailed=false,primaryError:unknown;
  const witness=async(label:string,observed:Record<string,unknown>)=>recordOfferEvidence(ui.army,`${code}-${label}`,{
    stage,projectId,versionId,importId,lineCount,expectedItemCount:oracle.expectedItemCount,expectedTotals,csvSha256:oracle.sha256,...observed});
  const registry=async()=>{
    const run=path.resolve(process.env.E2E_OFFER_RUN_DIRECTORY!);expect(run.startsWith(path.resolve(".e2e/army/offer/runs")+path.sep)).toBe(true);
    await writeFile(path.join(run,"private/large-owned-versions.json"),JSON.stringify(ui.army.ownedEstimates.map(item=>item.versionId)),{mode:0o600});
  };
  try{
    const initial=await createEstimateViaWizard(ui,{projectName:originalName,title:`ARMY grand devis ${lineCount}`},ui.army);
    projectId=initial.projectId;guard.project(projectId);await registry();
    const empty=await readEstimate(ui.browser,initial.versionId);expect(empty.items).toHaveLength(0);
    expect(empty.version).toMatchObject({margin_mode:"fixed",margin_multiplier:1,tax_rate_bp:2000,discount_bp:0,rounding_mode:"none",currency:"EUR",contractor_role:"principal"});
    const initialHash=digest(JSON.stringify(empty));
    const initialContent=withoutApprovalProjection(empty);
    stage="upload";await ui.app.open(`/dashboard/affaires/${projectId}?created=1`);
    await ui.screen.getByRole("button","Importer la DPGF",{exact:true}).click();
    await ui.browser.locator('input[type="file"]').setInputFiles(file);
    const uploadUrl=new URL("/api/imports",ui.app.baseUrl!).href;
    await ui.browser.evaluate(endpoint=>{
      type UploadObservation={status:number|null;ok:boolean;data:Record<string,unknown>|null;networkError:boolean;parseError:boolean};
      type Control={original:typeof window.fetch;wrapper:typeof window.fetch;requestCount:number;responseCount:number;observation:UploadObservation|null};
      const host=window as unknown as {__armyNrpgUpload?:Control};
      if(host.__armyNrpgUpload)throw new Error("Previous upload observer remains installed.");
      const original=window.fetch;
      const state={original,requestCount:0,responseCount:0,observation:null as UploadObservation|null,wrapper:null as unknown as typeof window.fetch};
      const wrapper:typeof window.fetch=async(input,init)=>{
        const address=new URL(input instanceof Request?input.url:String(input),location.href);
        const method=(init?.method??(input instanceof Request?input.method:"GET")).toUpperCase();
        const target=method==="POST"&&address.href===endpoint;
        if(target)state.requestCount+=1;
        try{
          const response=await original.call(window,input,init);
          if(target){
            state.responseCount+=1;
            try{
              const parsed:unknown=await response.clone().json();
              const record=parsed&&typeof parsed==="object"&&!Array.isArray(parsed)?parsed as Record<string,unknown>:null;
              const value=record?.data;
              const data=value&&typeof value==="object"&&!Array.isArray(value)?value as Record<string,unknown>:null;
              state.observation={status:response.status,ok:record?.ok===true,data:data?{id:data.id,project_id:data.project_id,filename:data.filename,row_count:data.row_count,source_format:data.source_format,status:data.status}:null,networkError:false,parseError:false};
            }catch{state.observation={status:response.status,ok:false,data:null,networkError:false,parseError:true};}
          }
          return response;
        }catch(error){
          if(target)state.observation={status:null,ok:false,data:null,networkError:true,parseError:false};
          throw error;
        }finally{if(target&&window.fetch===wrapper)window.fetch=original;}
      };
      state.wrapper=wrapper;host.__armyNrpgUpload=state;window.fetch=wrapper;
      return{installed:true,method:"POST",sameRequestAndResponse:true};
    },uploadUrl);
    await ui.screen.getByRole("button","Lancer l'import",{exact:true}).click();
    await expect.poll(async()=>await ui.browser.evaluate(()=>Boolean((window as unknown as {__armyNrpgUpload?:{observation:unknown}}).__armyNrpgUpload?.observation)),{timeout:120000}).toBe(true);
    const observedUpload=await ui.browser.evaluate(()=>{
      const state=(window as unknown as {__armyNrpgUpload?:{requestCount:number;responseCount:number;observation:{status:number|null;ok:boolean;data:Record<string,unknown>|null;networkError:boolean;parseError:boolean}|null}}).__armyNrpgUpload;
      return JSON.parse(JSON.stringify({requestCount:state?.requestCount??0,responseCount:state?.responseCount??0,observation:state?.observation??null}));
    });
    await witness("upload-http",{...observedUpload,expectedMethod:"POST",expectedStatus:201,observerOverridesRequest:false});
    expect(observedUpload.requestCount).toBe(1);expect(observedUpload.responseCount).toBe(1);
    expect(observedUpload.observation?.networkError).toBe(false);expect(observedUpload.observation?.parseError).toBe(false);
    expect(observedUpload.observation?.status).toBe(201);
    const upload=observedUpload.observation as unknown as {ok:boolean;data:ImportRecord};expect(upload.ok).toBe(true);
    importId=upload.data.id;expect(importId).toMatch(UUID);guard.imported(importId);
    const imports=await apiRequest<{ok:boolean;data:ImportRecord[]}>(ui.browser,"GET",`/api/imports?project_id=${projectId}`);
    expect(imports.status).toBe(200);expect(imports.body.ok).toBe(true);expect(imports.body.data).toHaveLength(1);
    expect(imports.body.data[0]).toMatchObject({id:importId,project_id:projectId,filename:oracle.filename,row_count:lineCount,source_format:"csv",status:"completed"});
    await witness("raw",{actualRawCount:imports.body.data[0].row_count,initialVersionId:initial.versionId,initialHash});
    stage="mapping";
    const next=ui.screen.getByRole("button","Suivant : Aperçu",{exact:true});
    const edit=ui.screen.getByRole("button","Modifier le mapping",{exact:true});
    await expect.poll(async()=>await next.isVisible()||await edit.isVisible(),{timeout:60000}).toBe(true);
    if(await edit.isVisible())await edit.click();await expect(next).toBeVisible();
    for(const key of fields)await ui.screen.getByRole("row").filter({has:ui.screen.getByText(key,{exact:true})}).getByRole("combobox").selectOption({value:key});
    await expect(next).toBeEnabled();await next.click();
    const preview=await apiRequest<{ok:boolean;data:{validation:{is_valid:boolean};rows:Array<{row_index:number;raw_row:Record<string,unknown>;mapped_row:Record<string,unknown>;missing_required_fields:string[]}>}}>(ui.browser,"POST","/api/mappings",{action:"preview",import_id:importId,mapping,limit:20});
    expect(preview.status).toBe(200);expect(preview.body.ok).toBe(true);expect(preview.body.data.validation.is_valid).toBe(true);
    expect(preview.body.data.rows).toHaveLength(Math.min(20,lineCount));
    for(const[i,row]of preview.body.data.rows.entries()){
      const line=oracle.lines[i];expect(row.row_index).toBe(i);
      expect(row.mapped_row).toMatchObject({hex_code:line.reference,designation:line.title,quantity:line.quantityText,unit:line.unit,unit_price_ht:money(line.unitPriceCents),total_ht:money(line.saleHtCents)});
      expect(row.missing_required_fields).toHaveLength(0);
    }
    await witness("mapped-preview",{previewRows:Math.min(20,lineCount),fullMappedRowsVerified:false,reason:"native companion will inspect all rows; preview is a bounded UI sample"});
    stage="canonical-confirm";
    await ui.screen.getByRole("button","Suivant : Confirmation",{exact:true}).click();
    await ui.screen.getByRole("button","Créer le chiffrage",{exact:true}).click();
    await expect(ui.screen.getByRole("heading","Devis créé",{exact:true})).toBeVisible({timeout:120000});
    // Register the actual created child before the editor can request its lease.
    // This is an authenticated GET of the owned project's new version, no seed.
    const latest=await apiRequest<{ok:boolean;data:{items:Array<{project_id:string;version_id:string;version_number:number}>}}>(ui.browser,"GET","/api/estimates");
    expect(latest.status).toBe(200);expect(latest.body.ok).toBe(true);
    const children=latest.body.data.items.filter(item=>item.project_id===projectId);expect(children).toHaveLength(1);expect(children[0].version_number).toBe(2);
    versionId=children[0].version_id;expect(versionId).toMatch(UUID);expect(versionId).not.toBe(initial.versionId);ownEstimate(ui.army,{projectId,versionId});
    await registry();
    await witness("canonical-version-created",{actualVersionNumber:2,source:"real confirmation plus owned authenticated GET before editor navigation"});
    await ui.screen.getByRole("button","Continuer",{exact:true}).click();
    const skip=ui.screen.getByRole("button","Continuer sans ajouter de plans",{exact:true});
    await expect.poll(async()=>/\/estimates\/[a-f0-9-]{36}\/edit/.test(await ui.browser.url())||await skip.isVisible(),{timeout:60000}).toBe(true);
    if(await skip.isVisible())await skip.click();await expect(ui.browser).toHaveURL(/\/estimates\/[a-f0-9-]{36}\/edit(?:[?#].*)?$/,{timeout:60000});
    expect((await ui.browser.url()).match(/\/estimates\/([a-f0-9-]{36})\/edit/)![1]).toBe(versionId);
    stage="owner-full-get";const saved=await readEstimateObserved(ui.browser,versionId,witness);
    await witness("owner-count",{actualItems:saved.items.length,actualLines:saved.items.filter(item=>item.item_type==="line").length,actualTotals:totals(saved.version),sourceProofComplete:false});
    expect(saved.items).toHaveLength(lineCount+1);expect(new Set(saved.items.map(item=>item.id)).size).toBe(lineCount+1);
    expect(totals(saved.version)).toEqual(expectedTotals);
    expect(saved.version).toMatchObject({status:"draft",calc_engine_version:2,margin_mode:"fixed",margin_multiplier:1,tax_rate_bp:2000,discount_bp:0,rounding_mode:"none",currency:"EUR",contractor_role:"principal"});
    const sections=saved.items.filter(item=>item.item_type==="section"),lines=saved.items.filter(item=>item.item_type==="line").sort((a,b)=>a.position-b.position||a.id.localeCompare(b.id));
    expect(sections).toHaveLength(1);expect(sections[0].parent_id).toBe(null);expect(lines).toHaveLength(lineCount);
    const mappedIds=new Set<string>(),mappingIds=new Set<string>();
    for(const[i,item]of lines.entries()){
      const line=oracle.lines[i];expect(item).toMatchObject({parent_id:sections[0].id,position:i+1,title:line.title,description:line.unit,quantity:line.quantity,unit_price_ht_cents:line.unitPriceCents,tax_rate_bp:2000,line_total_ht_cents:line.saleHtCents,line_tax_cents:line.taxCents,line_total_ttc_cents:line.totalTtcCents,source_provider:"dpgf",source_file_name:oracle.filename,source_page:null,selected_supplier_price_id:null});
      const source=item.source_metadata as Record<string,unknown>;expect(source).toMatchObject({import_id:importId,row_index:i});
      expect(source.mapping_id).toMatch(UUID);expect(source.mapped_row_id).toMatch(UUID);mappedIds.add(source.mapped_row_id as string);mappingIds.add(source.mapping_id as string);
      expect(source).not.toHaveProperty("_timax_provenance");
    }
    expect(mappedIds.size).toBe(lineCount);expect(mappingIds.size).toBe(1);
    const rangeFile=path.join(path.resolve(process.env.E2E_OFFER_RUN_DIRECTORY!),"public/large-pages.jsonl");
    const pages=(await readFile(rangeFile,"utf8")).trim().split(/\r?\n/).map(line=>JSON.parse(line)as{versionId?:string;observerError?:string;status:number;offset:string|null;limit:string|null;order:string|null;tenantScoped:boolean;rowCount:number});
    const ownPages=pages.filter(page=>page.versionId===versionId);
    await witness("range-pages-before-assert",{pageSize:500,
      observerErrorCount:pages.filter(page=>page.observerError!==undefined).length,
      actualOwnedPages:ownPages.map(page=>({status:page.status,offset:page.offset,limit:page.limit,order:page.order,tenantScoped:page.tenantScoped,rowCount:page.rowCount})),
      expectedOffsets:Array.from({length:Math.floor((lineCount+1)/500)+1},(_,i)=>i*500),
      zeroFinalPageRequired:(lineCount+1)%500===0});
    expect(pages.some(page=>page.observerError!==undefined)).toBe(false);
    expect(ownPages.length>0).toBe(true);expect(ownPages.every(page=>[200,206].includes(page.status)&&page.tenantScoped&&page.limit==="500"&&page.order==="position.asc,id.asc"&&page.rowCount<=500)).toBe(true);
    for(let offset=0;offset<=lineCount+1;offset+=500)expect(ownPages.some(page=>Number(page.offset)===offset&&page.rowCount===Math.min(500,lineCount+1-offset))).toBe(true);
    await witness("actual-range-boundaries",{pageSize:500,expectedOffsets:Array.from({length:Math.floor((lineCount+1)/500)+1},(_,i)=>i*500),observedOwnedPages:ownPages.length,zeroFinalPageRequired:(lineCount+1)%500===0});
    const originalAfter=await readEstimate(ui.browser,initial.versionId);
    const originalContentAfter=withoutApprovalProjection(originalAfter);
    const changedVersionKeys=[...new Set([...Object.keys(empty.version),...Object.keys(originalAfter.version)])].filter(key=>JSON.stringify(empty.version[key])!==JSON.stringify(originalAfter.version[key])).sort();
    const versionEvents=(await readFile(path.join(path.resolve(process.env.E2E_OFFER_RUN_DIRECTORY!),"public/large-version-events.jsonl"),"utf8")).trim().split(/\r?\n/).filter(Boolean).map(line=>JSON.parse(line)as{versionId?:string;method?:string;status?:number;startedAt?:string;finishedAt?:string;updateKeysAvailable?:boolean;updateKeys?:string[]});
    const originalPatches=versionEvents.filter(event=>event.versionId===initial.versionId&&event.method==="PATCH").map(event=>({method:event.method,status:event.status,startedAt:event.startedAt,finishedAt:event.finishedAt,updateKeysAvailable:event.updateKeysAvailable,updateKeys:event.updateKeys}));
    await witness("original-conservation",{changedVersionKeys,excludedVersionKeys:[...approvalProjectionKeys],coreEqual:JSON.stringify(originalContentAfter.version)===JSON.stringify(initialContent.version),projectEqual:JSON.stringify(originalAfter.project)===JSON.stringify(empty.project),itemsEqual:JSON.stringify(originalAfter.items)===JSON.stringify(empty.items),originalPatches,singleOriginalGet:true,retried:false});
    expect(originalContentAfter).toEqual(initialContent);
    stage="reload";await ui.browser.reload();
    await expect(ui.screen.getByRole("heading","Éditer le chiffrage",{exact:true})).toBeVisible();
    const reloaded=await readEstimate(ui.browser,versionId);expect(reloaded.items).toEqual(saved.items);expect(totals(reloaded.version)).toEqual(expectedTotals);
    await witness("full-import-reloaded",{actualItems:reloaded.items.length,actualLines:lines.length,mappedIds:lineCount,mappingId:[...mappingIds][0],idsOrderSha256:digest(lines.map(item=>item.id).join("\n")),provenanceChecked:true,positivePdfSourceDocumentProof:false,initialUnchanged:true});
    const mutableMoney = new Set(["updated_at", "quantity", "pu_ht_cents", "line_total_ht_cents", "line_tax_cents", "line_total_ttc_cents"]);
    const stableRows = (items: ArmyItem[]) => items.map(item => Object.fromEntries(Object.entries(item).filter(([key]) => !mutableMoney.has(key))));
    const originalStableRows = stableRows(saved.items);
    for (const operation of finance.stages) {
      stage = `euro-${operation.label}`;
      const beforeSave = await readEstimateObserved(ui.browser, versionId, async (label, values) => witness(`${operation.label}-before-${label}`, values));
      expect(typeof beforeSave.version.content_revision).toBe("number");
      expect(Number.isSafeInteger(beforeSave.version.content_revision)).toBe(true);
      if (operation.action !== "quantity" && operation.action !== "api-prepare" && operation.action !== "api-refuse") {
        await ui.screen.getByRole("button", "Ouvrir les paramètres", { exact: true }).click();
        const drawer = ui.screen.getByRole("dialog", "Paramétrage du devis", { exact: true });
        await expect(drawer).toBeVisible();
        if (operation.fillMargin !== undefined) {
          await drawer.getByLabel("Marge", { exact: true }).fill(String(operation.fillMargin));
          await drawer.getByLabel("Marge", { exact: true }).press("Tab");
        }
        if (operation.fillDiscountCents !== undefined) {
          await drawer.getByLabel("Remise (EUR HT)", { exact: true }).fill((operation.fillDiscountCents / 100).toFixed(2));
          await drawer.getByLabel("Remise (EUR HT)", { exact: true }).press("Tab");
        }
        if (operation.fillTitle) await drawer.getByLabel("Titre", { exact: true }).fill(`${ui.army.runPrefix}-${operation.label}`);
        await witness(`${operation.label}-entered`, { requestedDiscountCents: operation.requestedDiscountCents, expectedAppliedDiscountCents: operation.appliedDiscountCents,
          source: "real drawer; discount not touched for margin/title-only", fillDiscountCents: operation.fillDiscountCents ?? null, financialOracleSha256 });
      }
      await ui.browser.evaluate(endpoint=>{
        type Event={kind:string;method:string;operation:string;startedAt:string;finishedAt?:string;status?:number|null;ok?:boolean;errorCode?:string|null;ifMatch:string|null;leasePresent:boolean;requestRevisionPresent:boolean;requestRevision:number|null;requestDiscountPresent:boolean;requestDiscountAmountCents:number|null;responseRevision:number|null;responseTotals:unknown;responseItemCount:number|null;networkError?:boolean;parseError?:boolean;requestUnchanged:true};
        type Control={original:typeof window.fetch;wrapper:typeof window.fetch;events:Event[];inflight:number};
        const host=window as unknown as {__armySat?:Control};
        if(host.__armySat)throw new Error("Previous atomic settings observer remains installed.");
        const original=window.fetch;
        const state={original,events:[] as Event[],inflight:0,wrapper:null as unknown as typeof window.fetch};
        const target=new URL(endpoint);
        const wrapper:typeof window.fetch=async(input,init)=>{
          const address=new URL(input instanceof Request?input.url:String(input),location.href);
          const method=(init?.method??(input instanceof Request?input.method:"GET")).toUpperCase();
          const suffix=address.pathname.startsWith(target.pathname+"/")?address.pathname.slice(target.pathname.length+1):null;
          const mutation=address.origin===target.origin&&!["GET","HEAD","OPTIONS"].includes(method)
            &&(address.pathname===target.pathname||suffix!==null);
          if(!mutation)return original.call(window,input,init);
          const headers=new Headers(init?.headers??(input instanceof Request?input.headers:undefined));
          let request:Record<string,unknown>|null=null;
          try{const raw=typeof init?.body==="string"?init.body:input instanceof Request?await input.clone().text():null;
            const parsed:unknown=raw?JSON.parse(raw):null;if(parsed&&typeof parsed==="object"&&!Array.isArray(parsed))request=parsed as Record<string,unknown>;
          }catch{/* Record only metadata. A parse error does not alter the request. */}
          const revision=request?.expected_content_revision;
          const event:Event={kind:address.pathname===target.pathname&&method==="PATCH"?"settings-patch":suffix==="lock"?"lease":/^(?:items(?:\/|$)|batch(?:\/|$))/.test(suffix??"")?"line-mutation":"other-mutation",
            method,operation:suffix??"",startedAt:new Date().toISOString(),ifMatch:headers.get("if-match"),
            leasePresent:[...headers.keys()].some(key=>key.toLowerCase().includes("session")||key.toLowerCase().includes("lock")),
            requestRevisionPresent:typeof revision==="number"&&Number.isSafeInteger(revision),requestRevision:typeof revision==="number"&&Number.isSafeInteger(revision)?revision:null,
            requestDiscountPresent:Boolean(request&&Object.hasOwn(request,"discount_amount_cents")),requestDiscountAmountCents:typeof request?.discount_amount_cents==="number"?request.discount_amount_cents:null,
            responseRevision:null,responseTotals:null,responseItemCount:null,requestUnchanged:true};
          state.events.push(event);state.inflight++;
          try{
            const response=await original.call(window,input,init);event.status=response.status;
            try{
              const body=await response.clone().json() as {ok?:boolean;error?:{code?:string};data?:{version?:Record<string,unknown>;items?:unknown[]}};
              event.ok=body.ok===true;event.errorCode=typeof body.error?.code==="string"?body.error.code:null;
              const version=body.data?.version;event.responseTotals=version?[version.total_ht_cents,version.total_tax_cents,version.total_ttc_cents,version.rounding_adjustment_cents].map(value=>typeof value==="number"?value:null):null;
              event.responseRevision=typeof version?.content_revision==="number"?version.content_revision:null;
              event.responseItemCount=Array.isArray(body.data?.items)?body.data.items.length:null;
            }catch{event.parseError=true;}
            return response;
          }catch(error){event.status=null;event.networkError=true;throw error;}
          finally{event.finishedAt=new Date().toISOString();state.inflight--;}
        };
        state.wrapper=wrapper;host.__armySat=state;window.fetch=wrapper;
        return{installed:true,originalRequestAndResponse:true,scope:"all owned estimate mutations until visible save completion and authoritative GET"};
      },new URL(`/api/estimates/${versionId}`,ui.app.baseUrl!).href);
      if (operation.action === "api-prepare" || operation.action === "api-refuse") {
        const prepared = await ui.browser.evaluate(async ({ endpoint, updatedAt, revision, versionId, patch }: {endpoint:string;updatedAt:string;revision:number;versionId:string;patch:Record<string,string|number|null|number[]>}) => {
          const lease = (window as unknown as { __miaouffrageEstimateDraftLockSessions?: Map<string, string> }).__miaouffrageEstimateDraftLockSessions?.get(versionId);
          if (!lease || !/^[a-f0-9-]{36}$/i.test(lease)) throw new Error("Actual owned editor lease unavailable.");
          const response = await fetch(endpoint, { method: "PATCH", credentials: "same-origin", headers: {
            "Content-Type": "application/json", "If-Match": updatedAt, "x-estimate-draft-lock-session-id": lease,
          }, body: JSON.stringify({ ...patch, updated_at: updatedAt, expected_content_revision: revision }) });
          return { status: response.status, body: await response.json() };
        }, { endpoint: new URL(`/api/estimates/${versionId}`, ui.app.baseUrl!).href, updatedAt: beforeSave.version.updated_at,
          revision: beforeSave.version.content_revision as number, versionId, patch: operation.preparationPatch! }) as { status: number; body: ObservedEnvelope };
        await witness(`${operation.label}-ordinary-api-preparation`, { status: prepared.status, body: prepared.body, privateLeaseReturned: false,
          expectedRefusal: operation.action === "api-refuse", expectedHttpStatus: operation.expectedHttpStatus ?? 200, expectedErrorCode: operation.expectedErrorCode ?? null,
          originalCas: { updatedAt: beforeSave.version.updated_at, revision: beforeSave.version.content_revision }, source: "ordinary authenticated owned draft API; readonly historical parameters; no SQL seed" });
        if (operation.action === "api-refuse") {
          expect(prepared.status).toBe(operation.expectedHttpStatus!);
          expect(prepared.body.ok).toBe(false);
          expect(prepared.body.error?.code).toBe(operation.expectedErrorCode!);
        } else { expect(prepared.status).toBe(200); expect(prepared.body.ok).toBe(true); }
      } else if (operation.action === "quantity") {
        const quantity = ui.screen.getByLabel(`Quantité pour ${oracle.lines[0].title}`, { exact: true });
        await expect(quantity).toBeVisible(); await quantity.fill(operation.quantityText); await quantity.press("Tab");
      } else {
        const drawer = ui.screen.getByRole("dialog", "Paramétrage du devis", { exact: true });
        await drawer.getByRole("button", "Enregistrer le paramétrage", { exact: true }).click();
      }
      await expect.poll(async () => await ui.browser.evaluate(action => {
        const state = (window as unknown as { __armySat?: { events: Array<{ kind: string; finishedAt?: string }>; inflight: number } }).__armySat;
        return Boolean(state && state.inflight === 0 && state.events.some(event => event.kind === (action === "quantity" ? "line-mutation" : "settings-patch") && event.finishedAt));
      }, operation.action), { timeout: 120000 }).toBe(true);
      if (operation.action === "settings") {
        const drawer = ui.screen.getByRole("dialog", "Paramétrage du devis", { exact: true });
        await expect(drawer.getByRole("button", "Enregistrer le paramétrage", { exact: true })).toBeEnabled({ timeout: 120000 });
      }
      const afterSave = await readEstimateObserved(ui.browser, versionId, async (label, values) => witness(`${operation.label}-after-${label}`, values));
      const observed = await ui.browser.evaluate(() => {
        const host = window as unknown as { __armySat?: { original: typeof window.fetch; wrapper: typeof window.fetch; events: unknown[]; inflight: number } };
        const state = host.__armySat; if (!state) throw new Error("Euro observer unavailable.");
        const result = JSON.parse(JSON.stringify({ events: state.events, inflight: state.inflight }));
        if (window.fetch === state.wrapper) window.fetch = state.original; delete host.__armySat; return result;
      }) as { events: Array<{ kind: string; operation: string; method: string; status: number | null; ok?: boolean; errorCode?:string|null; ifMatch: string | null;
        leasePresent: boolean; requestRevisionPresent: boolean; requestRevision: number | null; responseTotals: number[] | null }>; inflight: number };
      const patches = observed.events.filter(event => event.kind === "settings-patch");
      const lineMutations = observed.events.filter(event => event.kind === "line-mutation");
      const otherMutations = observed.events.filter(event => event.kind === "other-mutation");
      await witness(`${operation.label}-before-assertions`, { observed, originalUpdatedAt: beforeSave.version.updated_at, originalRevision: beforeSave.version.content_revision,
        actualVersion: afterSave.version, actualItems: afterSave.items, actualTotals: financialTotals(afterSave.version), expectedTotals: operation.totals,
        ...(operation.action === "api-refuse" ? { expectedUnchangedVersion: beforeSave.version, expectedUnchangedItems: beforeSave.items, expectedUnchangedProject: beforeSave.project,
          excludedVersionReadProjectionKeys: [...approvalProjectionKeys], refusalMustNotMutate: true } : {}),
        expectedRequestedDiscountCents: operation.requestedDiscountCents, expectedAppliedDiscountCents: operation.appliedDiscountCents, expectedSaleSubtotalCents: operation.saleSubtotalCents,
        source: operation.action === "api-prepare" || operation.action === "api-refuse" ? "explicit ordinary owned fixture preparation/rejection" : "real UI", originalRequestsUnchanged: true, financialOracleSha256 });
      expect(observed.inflight).toBe(0); expect(otherMutations).toHaveLength(0);
      expect(patches).toHaveLength(operation.action === "quantity" ? 0 : 1);
      expect(lineMutations).toHaveLength(operation.action === "quantity" ? 1 : 0);
      const mutation = operation.action === "quantity" ? lineMutations[0] : patches[0];
      if (operation.action === "api-refuse") {
        expect(mutation.status).toBe(operation.expectedHttpStatus!); expect(mutation.ok).toBe(false);
        expect(mutation.errorCode).toBe(operation.expectedErrorCode!);
        expect(withoutApprovalProjection(afterSave)).toEqual(withoutApprovalProjection(beforeSave));
        expect(afterSave.version.updated_at).toBe(beforeSave.version.updated_at);
        expect(afterSave.version.content_revision as number).toBe(beforeSave.version.content_revision as number);
      } else { expect(mutation.status).toBe(200); expect(mutation.ok).toBe(true); }
      expect(mutation.leasePresent).toBe(true);
      expect(mutation.ifMatch).toBe(beforeSave.version.updated_at);
      expect(mutation.requestRevisionPresent).toBe(true); expect(mutation.requestRevision).toBe(beforeSave.version.content_revision as number);
      if (operation.action === "quantity") { expect(mutation.operation).toBe("batch"); expect(mutation.method).toBe("POST"); }
      expect(afterSave.items).toHaveLength(lineCount + 1); expect(stableRows(afterSave.items)).toEqual(originalStableRows);
      expect(financialTotals(afterSave.version)).toEqual(operation.totals);
      if (operation.requestedDiscountCents === null) expect((afterSave.version.discount_amount_cents ?? null) as number|null).toBe(null);
      else {
        expect(Object.hasOwn(afterSave.version,"discount_amount_cents")).toBe(true);
        expect(afterSave.version.discount_amount_cents as number|null).toBe(operation.requestedDiscountCents);
      }
      expect(afterSave.version).toMatchObject({ margin_multiplier: operation.margin, margin_mode: "fixed", global_coefficient: operation.globalCoefficient,
        discount_mode: operation.discountMode ?? "simple", contractor_role: "principal", rounding_mode: "none" });
      if (operation.requestedDiscountCents === null) {
        expect(afterSave.version.discount_bp).toBe(operation.discountBp!);
        expect(afterSave.version.discount_steps).toEqual(operation.discountSteps);
      } else expect(afterSave.version.discount_steps).toEqual([]);
      if (operation.fillTitle) expect(afterSave.version.title).toBe(`${ui.army.runPrefix}-${operation.label}`);
      const afterLines = afterSave.items.filter(item => item.item_type === "line").sort((a, b) => a.position - b.position || a.id.localeCompare(b.id));
      for (const [i, item] of afterLines.entries()) {
        const expected = operation.lines[i];
        expect(item).toMatchObject({ quantity: expected.quantity, unit_price_ht_cents: oracle.lines[i].unitPriceCents, pu_ht_cents: expected.snapshotPuHtCents,
          line_total_ht_cents: expected.netHtCents, line_tax_cents: expected.taxCents, line_total_ttc_cents: expected.ttcCents });
      }
      expect(afterLines.reduce((sum, item) => sum + Number(item.line_total_ht_cents), 0)).toBe(operation.totals[0]);
      expect(afterLines.reduce((sum, item) => sum + Number(item.line_tax_cents), 0)).toBe(operation.totals[1]);
      expect(afterLines.reduce((sum, item) => sum + Number(item.line_total_ttc_cents), 0)).toBe(operation.totals[2]);
      await ui.browser.reload();
      await expect(ui.screen.getByRole("heading", "Éditer le chiffrage", { exact: true })).toBeVisible();
      const afterReload = await readEstimateObserved(ui.browser, versionId, async (label, values) => witness(`${operation.label}-reload-${label}`, values));
      await witness(`${operation.label}-reload-before-assertions`, { actualItems: afterReload.items, actualVersion: afterReload.version,
        expectedTotals: operation.totals, expectedRequestedDiscountCents: operation.requestedDiscountCents, expectedAppliedDiscountCents: operation.appliedDiscountCents });
      expect(afterReload.items).toEqual(afterSave.items); expect(financialTotals(afterReload.version)).toEqual(operation.totals);
      if (operation.requestedDiscountCents === null) expect((afterReload.version.discount_amount_cents ?? null) as number|null).toBe(null);
      else {
        expect(Object.hasOwn(afterReload.version,"discount_amount_cents")).toBe(true);
        expect(afterReload.version.discount_amount_cents as number|null).toBe(operation.requestedDiscountCents);
      }
      await ui.screen.getByRole("button", "Ouvrir les paramètres", { exact: true }).click();
      const reloadedDrawer = ui.screen.getByRole("dialog", "Paramétrage du devis", { exact: true }); await expect(reloadedDrawer).toBeVisible();
      if ((operation.discountMode ?? "simple") === "simple") {
        const persistedDiscount = await reloadedDrawer.getByLabel("Remise (EUR HT)", { exact: true }).inputValue();
        const persistedDiscountCents = Math.round(Number(persistedDiscount.replace(",", ".")) * 100);
        const expectedControlCents = operation.requestedDiscountCents ?? operation.appliedDiscountCents;
        await witness(`${operation.label}-discount-control`, { persistedDiscount, persistedDiscountCents, expectedControlCents,
          expectedRequestedDiscountCents: operation.requestedDiscountCents, expectedAppliedDiscountCents: operation.appliedDiscountCents });
        expect(persistedDiscountCents).toBe(expectedControlCents);
      } else {
        await expect(reloadedDrawer.getByText("Remises historiques conservées", { exact: true })).toBeVisible();
        await expect(reloadedDrawer.getByLabel("Remise (EUR HT)", { exact: true })).toBeHidden();
      }
      await reloadedDrawer.getByRole("button", "Fermer", { exact: true }).click(); await expect(reloadedDrawer).toBeHidden();
      await witness(`${operation.label}-qualified`, { actualTotals: financialTotals(afterReload.version), actualItems: afterReload.items.length,
        allLineMoneyChecked: true, allSourcePricesAndProvenanceUnchanged: true, originalBusinessMutationOnly: true,
        requestNotReplacedByAppliedAmount: operation.requestedDiscountCents === null ? null : afterReload.version.discount_amount_cents === operation.requestedDiscountCents,
        financialOracleSha256, publicationQualified: false, engine: "V2" });
    }
    const collectorPath=path.resolve(process.env.E2E_OFFER_COLLECTOR_DIRECTORY!,"receipts");
    const receiptEntries=await readdir(collectorPath);expect(receiptEntries).toHaveLength(0);
    stage="complete-euro";await witness("euro-complete",{financialSettingsExecuted:true,collectorReceiptEntries:receiptEntries.length,pdfEmissionExecuted:false,nativeCountsQualified:false});
  }catch(error){primaryFailed=true;primaryError=error;throw error;}
  finally{
    const cleanupErrors:string[]=[];let cleanupFailed=false,firstCleanupError:unknown;
    const captureCleanup=(phase:string,error:unknown)=>{cleanupErrors.push(phase);if(!cleanupFailed){cleanupFailed=true;firstCleanupError=error;}};
    try { const observer = await ui.browser.evaluate(() => { const state = (window as unknown as { __armySat?: { events: unknown[]; inflight: number } }).__armySat; return JSON.parse(JSON.stringify(state ? { events: state.events, inflight: state.inflight } : { events: [], inflight: 0 })); }); await witness("final-observer", { observer }); } catch(error) { captureCleanup("final-observer",error); }
    try{await witness("identities-before-cleanup",{retained:true,complete:stage.startsWith("complete"),primaryFailed,
      primaryErrorType:primaryError instanceof Error?primaryError.name:null,
      primaryMessageSha256:primaryError instanceof Error?digest(primaryError.message):null,
      cleanupStarted:false});}catch(error){captureCleanup("identities-witness",error);}
    try{await ui.browser.evaluate(()=>{
      const host=window as unknown as {__armyNrpgUpload?:{original:typeof window.fetch;wrapper:typeof window.fetch}};
      if(host.__armyNrpgUpload&&window.fetch===host.__armyNrpgUpload.wrapper)window.fetch=host.__armyNrpgUpload.original;
      delete host.__armyNrpgUpload;return{observerRemoved:true};
    });}catch(error){captureCleanup("upload-observer-close",error);}
    try{await ui.browser.evaluate(()=>{const host=window as unknown as {__armySat?:{original:typeof window.fetch;wrapper:typeof window.fetch}};if(host.__armySat&&window.fetch===host.__armySat.wrapper)window.fetch=host.__armySat.original;delete host.__armySat;return{observerRemoved:true};});}catch(error){captureCleanup("settings-observer-close",error);}
    try{await guard.close();}catch(error){captureCleanup("guard-close",error);}
    try{await witness("retained",{retained:true,cleanup:"admission closed only; no fixture deletion",complete:stage.startsWith("complete"),primaryFailed,cleanupErrors,
      sourceDocumentProof:"CSV has no PDF sourceDocumentId; positive PDF provenance is separate"});}catch(error){captureCleanup("retained-witness",error);}
    if(cleanupFailed&&!primaryFailed)throw firstCleanupError;
  }
});
